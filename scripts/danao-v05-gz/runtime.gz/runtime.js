import { GAME_CONFIG } from './config.js';
import { getArena } from './arena.js';
import { applyHit } from './rules.js';
import { botIntent } from './bot.js';
import { createInputEdges, neutralInput } from './input.js';
import { cameraFrameForPoints, partyCameraPlacement, movementVector, nearestOpponent } from './runtimeMath.js';
import { createArcadeAudio } from './audio.js';
import { countdownState, edgeDanger, fighterPose } from './presentation.js';
import { BABYLON_URLS, RAPIER_URLS } from './dependencies.js';
import { getItemDefinition, heldAttackProfile, throwProfile, nearestCarryTarget } from './items.js';
import { knockdownDuration, impactDamage, roundWinner, hitStopDuration } from './brawler.js';
import { carryAnchorPosition, throwVelocity, clampPlanarVelocity } from './interactions.js';


const FIGHTER_STYLES = Object.freeze([
  { id: 'hero', name: 'Hero', primary: '#27C8B9', secondary: '#FFD84F', skin: '#e3aa73', bodyScale: [0.83, 1.02, 0.58] },
  { id: 'stephen', name: 'Stephen', primary: '#F07B4B', secondary: '#2D3448', skin: '#e3aa73', bodyScale: [0.91, 1.0, 0.63] },
  { id: 'zachary', name: 'Zachary', primary: '#4E88E8', secondary: '#E7D067', skin: '#e3aa73', bodyScale: [0.79, 1.05, 0.56] },
  { id: 'mulan', name: 'Mulan', primary: '#B75ED8', secondary: '#F4C9DD', skin: '#e3aa73', bodyScale: [0.77, 1.03, 0.55] },
  { id: 'gaby', name: 'Gaby', primary: '#6ABC5B', secondary: '#F0CB62', skin: '#e3aa73', bodyScale: [0.84, 0.99, 0.60] },
  { id: 'sara', name: 'Sara', primary: '#E39A3B', secondary: '#6A8FCB', skin: '#e3aa73', bodyScale: [0.80, 1.03, 0.56] },
  { id: 'mum', name: 'Mum', primary: '#E76891', secondary: '#F1D5B5', skin: '#e3aa73', bodyScale: [0.84, 1.04, 0.59] },
  { id: 'dad', name: 'Dad', primary: '#697386', secondary: '#A9C5A5', skin: '#e3aa73', bodyScale: [0.93, 1.02, 0.65] },
]);

const FIXED_STEP = 1 / 60;

import { hexToRgb, createFighterVisual, createPropVisual, createShadow, createArenaVisual, spawnImpact, spawnPropDebris } from './visuals.js';

async function loadBabylon(onStatus = () => {}) {
  if (globalThis.BABYLON) return globalThis.BABYLON;
  let lastError = null;
  for (const url of BABYLON_URLS) {
    try {
      onStatus('Loading Babylon renderer…');
      await new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = url;
        script.async = true;
        script.onload = resolve;
        script.onerror = () => reject(new Error(`Could not load ${url}`));
        document.head.appendChild(script);
      });
      if (globalThis.BABYLON) return globalThis.BABYLON;
    } catch (error) {
      lastError = error;
    }
  }
  throw new Error(`Babylon.js could not load. ${lastError?.message || ''}`.trim());
}

async function loadRapier(onStatus = () => {}) {
  let lastError = null;
  for (const url of RAPIER_URLS) {
    try {
      onStatus('Loading Rapier physics…');
      const module = await import(url);
      const RAPIER = module.default ?? module;
      await RAPIER.init();
      return RAPIER;
    } catch (error) {
      lastError = error;
    }
  }
  throw new Error(`Rapier physics could not load. ${lastError?.message || ''}`.trim());
}

function readGamepad(index = 0) {
  const pads = globalThis.navigator?.getGamepads?.() || [];
  const pad = pads[index];
  if (!pad) return null;
  const dead = (value) => Math.abs(value) < 0.18 ? 0 : value;
  return {
    moveX: dead(pad.axes?.[0] || 0),
    moveZ: -dead(pad.axes?.[1] || 0),
    jump: Boolean(pad.buttons?.[0]?.pressed),
    dodge: Boolean(pad.buttons?.[1]?.pressed),
    light: Boolean(pad.buttons?.[2]?.pressed),
    grab: Boolean(pad.buttons?.[3]?.pressed),
    heavy: Boolean(pad.buttons?.[7]?.pressed),
  };
}

function readKeyboard(keys) {
  return {
    moveX: (keys.has('KeyD') ? 1 : 0) - (keys.has('KeyA') ? 1 : 0),
    moveZ: (keys.has('KeyS') ? 1 : 0) - (keys.has('KeyW') ? 1 : 0),
    jump: keys.has('Space'),
    light: keys.has('KeyJ'),
    grab: keys.has('KeyK'),
    heavy: keys.has('KeyH'),
    dodge: keys.has('KeyL'),
  };
}

function mergeInput(a, b) {
  if (!b) return a;
  const moveX = Math.abs(b.moveX) > Math.abs(a.moveX) ? b.moveX : a.moveX;
  const moveZ = Math.abs(b.moveZ) > Math.abs(a.moveZ) ? b.moveZ : a.moveZ;
  return {
    moveX,
    moveZ,
    jump: a.jump || b.jump,
    light: a.light || b.light,
    heavy: a.heavy || b.heavy,
    grab: a.grab || b.grab,
    dodge: a.dodge || b.dodge,
  };
}

function styleOrder(selectedId) {
  const selected = FIGHTER_STYLES.find((style) => style.id === selectedId) || FIGHTER_STYLES[0];
  return [selected, ...FIGHTER_STYLES.filter((style) => style.id !== selected.id)];
}

export function createDanaoRuntime(canvas, callbacks = {}) {
  let B = globalThis.BABYLON || null;
  let RAPIER = null;
  let engine = null;
  let scene = null;
  let world = null;
  let camera = null;
  let currentArena = null;
  let fighters = [];
  let hazards = [];
  let props = [];
  let running = false;
  let paused = false;
  let matchOver = false;
  let matchStartedAt = 0;
  let pausedAt = 0;
  let lastCountdownLabel = null;
  let accumulator = 0;
  let lastFrame = 0;
  let lastHud = 0;
  let shake = 0;
  let hitStopUntil = 0;
  let settings = { masterVolume: 0.72, music: true, sfx: true, cameraShake: true };
  let audio = createArcadeAudio(settings);
  let timers = [];
  const keys = new Set();

  const onStatus = callbacks.onStatus || (() => {});
  const onHud = callbacks.onHud || (() => {});
  const onBanner = callbacks.onBanner || (() => {});
  const onBannerClear = callbacks.onBannerClear || (() => {});
  const onResult = callbacks.onResult || (() => {});

  function schedule(fn, delay) {
    const id = globalThis.setTimeout(() => {
      timers = timers.filter((value) => value !== id);
      fn();
    }, delay);
    timers.push(id);
    return id;
  }

  function clearTimers() {
    for (const id of timers) globalThis.clearTimeout(id);
    timers = [];
  }

  async function ensureRuntime() {
    if (!B) B = await loadBabylon(onStatus);
    if (!RAPIER) RAPIER = await loadRapier(onStatus);
    if (!engine) {
      engine = new B.Engine(canvas, true, { antialias: true, preserveDrawingBuffer: false, stencil: true }, true);
      engine.setHardwareScalingLevel(Math.max(1, (globalThis.devicePixelRatio || 1) / 1.5));
      globalThis.addEventListener?.('resize', () => engine?.resize());
    }
  }

  function buildScene(arena) {
    scene?.dispose();
    world?.free?.();
    scene = new B.Scene(engine);
    const sky = hexToRgb(arena.palette.sky);
    scene.clearColor = new B.Color4(sky.r, sky.g, sky.b, 1);
    scene.ambientColor = new B.Color3(0.55, 0.48, 0.45);

    const hemi = new B.HemisphericLight('hemi', new B.Vector3(0.25, 1, -0.2), scene);
    hemi.intensity = 1.0;
    hemi.groundColor = new B.Color3(0.24, 0.18, 0.2);
    const sun = new B.DirectionalLight('sun', new B.Vector3(-0.4, -1, 0.25), scene);
    sun.position = new B.Vector3(10, 18, -10);
    sun.intensity = 1.15;

    camera = new B.FreeCamera('shared-camera', new B.Vector3(8.5, 10.5, -13.5), scene);
    camera.fov = 0.78;
    camera.minZ = 0.2;
    camera.maxZ = 120;
    camera.setTarget(B.Vector3.Zero());
    scene.activeCamera = camera;

    const arenaVisual = createArenaVisual(B, scene, arena);
    hazards = arenaVisual.hazardVisuals;

    world = new RAPIER.World({ x: 0, y: -19.5, z: 0 });
    world.timestep = FIXED_STEP;
    world.createCollider(
      RAPIER.ColliderDesc.cuboid(arena.size.x / 2, 0.3, arena.size.z / 2)
        .setTranslation(0, -0.3, 0)
        .setFriction(1.2)
        .setRestitution(0.05),
    );
    if (arena.ring) {
      world.createCollider(
        RAPIER.ColliderDesc.cuboid(arena.ring.size.x / 2, arena.ring.topY / 2, arena.ring.size.z / 2)
          .setTranslation(0, arena.ring.topY / 2, 0)
          .setFriction(1.08)
          .setRestitution(0.03),
      );
    }
    props = [];
    spawnArenaProps(arena);
  }

  function surfaceYAt(x, z) {
    const ring = currentArena?.ring;
    if (ring && Math.abs(x) <= ring.size.x / 2 && Math.abs(z) <= ring.size.z / 2) return ring.topY;
    return currentArena?.floorY ?? 0;
  }

  function createProp(definition, spawn, index) {
    const size = definition.size || [0.8, 0.8, 0.8];
    const volume = Math.max(0.05, size[0] * size[1] * size[2]);
    const y = (spawn.y ?? surfaceYAt(spawn.x, spawn.z)) + size[1] / 2 + 0.06;
    const body = world.createRigidBody(
      RAPIER.RigidBodyDesc.dynamic()
        .setTranslation(spawn.x, y, spawn.z)
        .setLinearDamping(1.25)
        .setAngularDamping(1.15),
    );
    const yaw = Number(spawn.yaw) || 0;
    body.setRotation?.({ x: 0, y: Math.sin(yaw / 2), z: 0, w: Math.cos(yaw / 2) }, true);
    world.createCollider(
      RAPIER.ColliderDesc.cuboid(size[0] / 2, size[1] / 2, size[2] / 2)
        .setDensity(Math.max(0.12, definition.mass / volume))
        .setFriction(0.72)
        .setRestitution(definition.kind === 'baguette' ? 0.28 : 0.12),
      body,
    );
    const visual = createPropVisual(B, scene, definition);
    visual.position.set(spawn.x, y, spawn.z);
    visual.rotation.y = yaw;
    return {
      id: `prop-${index}-${definition.id}`,
      definition,
      body,
      visual,
      holderId: null,
      hp: Number.isFinite(definition.hp) ? definition.hp : Infinity,
      broken: false,
      lastThrownBy: null,
      throwArmedUntil: 0,
      lastImpactAt: new Map(),
    };
  }

  function spawnArenaProps(arena) {
    const entries = arena.props || [];
    props = entries.map((spawn, index) => createProp(getItemDefinition(spawn.itemId), {
      ...spawn,
      y: spawn.onRing && arena.ring ? arena.ring.topY : arena.floorY,
    }, index));
  }

  function propPosition(prop) {
    const p = prop.body.translation();
    return { x: p.x, y: p.y, z: p.z };
  }

  function createFighter(slot, spawn, style, control) {
    const body = world.createRigidBody(
      RAPIER.RigidBodyDesc.dynamic()
        .setTranslation(spawn.x, spawn.y, spawn.z)
        .setLinearDamping(3.8)
        .setAngularDamping(8)
        .lockRotations(),
    );
    world.createCollider(
      RAPIER.ColliderDesc.capsule(0.53, 0.43)
        .setDensity(1.1)
        .setFriction(0.55)
        .setRestitution(0.04),
      body,
    );

    const visual = createFighterVisual(B, scene, style, slot === 0);
    const shadow = createShadow(B, scene);
    return {
      id: `p${slot + 1}`,
      slot,
      name: slot === 0 ? style.name : `${style.name}${control.type === 'bot' ? ' Bot' : ` P${slot + 1}`}`,
      style,
      control,
      body,
      visual,
      shadow,
      spawn,
      health: GAME_CONFIG.maxHealth,
      score: 0,
      active: true,
      direction: { x: 0, z: 1 },
      previousInput: neutralInput(),
      attackReadyAt: 0,
      dodgeReadyAt: 0,
      hitStunUntil: 0,
      invulnerableUntil: 0,
      lastAttackerId: null,
      lastAttackedAt: 0,
      attackPulseUntil: 0,
      attackKind: '',
      attackUntil: 0,
      dodgePoseUntil: 0,
      heldPropId: null,
      grabbedFighterId: null,
      grabbedById: null,
      knockedDownUntil: 0,
      ko: false,
    };
  }

  function fighterPosition(fighter) {
    const p = fighter.body.translation();
    return { x: p.x, y: p.y, z: p.z };
  }

  function getHeldProp(fighter) {
    return fighter?.heldPropId ? props.find((prop) => prop.id === fighter.heldPropId && !prop.broken) || null : null;
  }

  function setPropCarried(prop, carried) {
    if (!prop || prop.broken) return;
    if (prop.body.setBodyType && RAPIER?.RigidBodyType) {
      prop.body.setBodyType(carried ? RAPIER.RigidBodyType.KinematicPositionBased : RAPIER.RigidBodyType.Dynamic, true);
    } else {
      prop.body.setGravityScale?.(carried ? 0 : 1, true);
    }
    prop.body.setLinvel?.({ x: 0, y: 0, z: 0 }, true);
    prop.body.setAngvel?.({ x: 0, y: 0, z: 0 }, true);
  }

  function pickupProp(fighter, prop) {
    if (!fighter?.active || !prop || prop.broken || prop.holderId || fighter.heldPropId || fighter.grabbedFighterId) return false;
    prop.holderId = fighter.id;
    prop.lastThrownBy = null;
    prop.throwArmedUntil = 0;
    fighter.heldPropId = prop.id;
    setPropCarried(prop, true);
    audio.grab?.();
    return true;
  }

  function dropHeldProp(fighter, now = performance.now(), throwIt = false) {
    const prop = getHeldProp(fighter);
    if (!prop) {
      fighter.heldPropId = null;
      return null;
    }
    const fp = fighter.body.translation();
    const anchor = carryAnchorPosition(fp, fighter.direction, 1.18, 0.72);
    fighter.heldPropId = null;
    prop.holderId = null;
    setPropCarried(prop, false);
    prop.body.setTranslation?.(anchor, true);
    if (throwIt) {
      const power = Math.max(10.5, 16.5 - prop.definition.mass * 0.42);
      const velocity = throwVelocity(fighter.direction, fighter.body.linvel(), power, 19);
      prop.body.setLinvel?.(velocity, true);
      prop.body.setAngvel?.({ x: 2.5, y: 4.2, z: -2.1 }, true);
      prop.lastThrownBy = fighter.id;
      prop.throwArmedUntil = now + 1100;
      audio.throw?.();
    }
    return prop;
  }

  function releaseGrabbedFighter(fighter, now = performance.now(), throwIt = false) {
    if (!fighter?.grabbedFighterId) return null;
    const target = fighters.find((other) => other.id === fighter.grabbedFighterId) || null;
    fighter.grabbedFighterId = null;
    if (!target) return null;
    target.grabbedById = null;
    if (throwIt && target.active) {
      const result = applyHit({ health: target.health }, { damage: 7, knockback: 10 });
      target.health = result.health;
      target.lastAttackerId = fighter.id;
      target.lastAttackedAt = now;
      target.hitStunUntil = now + 360;
      target.knockedDownUntil = now + knockdownDuration(12, target.health);
      target.body.lockRotations?.(false, true);
      target.body.setLinvel(throwVelocity(fighter.direction, fighter.body.linvel(), 14, 18), true);
      target.body.setAngvel?.({ x: 4.2, y: 1.5, z: -3.1 }, true);
      hitStopUntil = Math.max(hitStopUntil, now + hitStopDuration(12, true));
      if (target.health <= 0) knockOut(target, fighter.id, 'THROWN OUT COLD');
    }
    return target;
  }

  function releaseEverything(fighter, now = performance.now()) {
    dropHeldProp(fighter, now, false);
    releaseGrabbedFighter(fighter, now, false);
    if (fighter?.grabbedById) {
      const holder = fighters.find((other) => other.id === fighter.grabbedById);
      if (holder) holder.grabbedFighterId = null;
      fighter.grabbedById = null;
    }
  }

  function performGrab(fighter, now) {
    if (!fighter?.active || now < fighter.hitStunUntil || now < fighter.knockedDownUntil || fighter.grabbedById) return false;
    if (fighter.heldPropId) return Boolean(dropHeldProp(fighter, now, true));
    if (fighter.grabbedFighterId) return Boolean(releaseGrabbedFighter(fighter, now, true));

    const origin = fighterPosition(fighter);
    const propTarget = nearestCarryTarget(origin, fighter.direction, props.map((prop) => {
      const p = propPosition(prop);
      return { id: prop.id, x: p.x, z: p.z, carryable: !prop.broken && !prop.holderId, ref: prop };
    }), 2.15);
    const fighterTarget = nearestCarryTarget(origin, fighter.direction, fighters.map((target) => {
      const p = fighterPosition(target);
      const closeEnoughToGrab = target.id !== fighter.id && target.active && !target.grabbedById && !target.heldPropId && (target.knockedDownUntil > now || Math.hypot(p.x - origin.x, p.z - origin.z) < 1.15);
      return { id: target.id, x: p.x, z: p.z, carryable: closeEnoughToGrab, ref: target };
    }), 1.72);

    const propDistance = propTarget ? Math.hypot(propTarget.x - origin.x, propTarget.z - origin.z) : Infinity;
    const fighterDistance = fighterTarget ? Math.hypot(fighterTarget.x - origin.x, fighterTarget.z - origin.z) : Infinity;
    if (propTarget && propDistance <= fighterDistance + 0.18) return pickupProp(fighter, propTarget.ref);
    if (fighterTarget?.ref) {
      const target = fighterTarget.ref;
      fighter.grabbedFighterId = target.id;
      target.grabbedById = fighter.id;
      target.hitStunUntil = Math.max(target.hitStunUntil, now + 260);
      target.knockedDownUntil = Math.max(target.knockedDownUntil, now + 260);
      audio.grab?.();
      return true;
    }
    return false;
  }

  function syncHeldTargets(now) {
    for (const fighter of fighters) {
      if (!fighter.active) continue;
      const fp = fighter.body.translation();
      const anchor = carryAnchorPosition(fp, fighter.direction, 1.18, 0.72);
      const prop = getHeldProp(fighter);
      if (prop) {
        if (prop.body.setNextKinematicTranslation) prop.body.setNextKinematicTranslation(anchor);
        else prop.body.setTranslation(anchor, true);
      }
      if (fighter.grabbedFighterId) {
        const target = fighters.find((other) => other.id === fighter.grabbedFighterId && other.active);
        if (!target) {
          fighter.grabbedFighterId = null;
          continue;
        }
        const tp = target.body.translation();
        const dx = anchor.x - tp.x;
        const dy = (anchor.y - 0.25) - tp.y;
        const dz = anchor.z - tp.z;
        const follow = clampPlanarVelocity({ x: dx * 8.5, y: dy * 6.5, z: dz * 8.5 }, 11.5);
        target.body.setLinvel(follow, true);
        target.hitStunUntil = Math.max(target.hitStunUntil, now + 120);
      }
    }
  }

  function breakProp(prop, now = performance.now()) {
    if (!prop || prop.broken) return;
    const p = prop.body.translation();
    const holder = fighters.find((fighter) => fighter.heldPropId === prop.id);
    if (holder) holder.heldPropId = null;
    prop.broken = true;
    prop.holderId = null;
    prop.lastThrownBy = null;
    prop.throwArmedUntil = 0;
    prop.body.setEnabled?.(false);
    spawnPropDebris(B, scene, new B.Vector3(p.x, p.y, p.z), prop.definition.kind, prop.definition.size);
    prop.visual.setEnabled(false);
    audio.hit(true);
    hitStopUntil = Math.max(hitStopUntil, now + hitStopDuration(11, true));
    spawnImpact(B, scene, new B.Vector3(p.x, p.y, p.z), '#f2c94c', true, (value) => { shake = Math.max(shake, value); });
    schedule(() => prop.visual.dispose?.(), 260);
  }

  function damageProp(prop, damage, now = performance.now()) {
    if (!prop || prop.broken || !Number.isFinite(prop.hp)) return false;
    prop.hp -= Math.max(0, Number(damage) || 0);
    if (prop.hp <= 0) {
      breakProp(prop, now);
      return true;
    }
    return false;
  }

  function updatePropHighlights() {
    const local = fighters[0];
    let focusedId = null;
    if (local?.active && !local.heldPropId && !local.grabbedFighterId && !local.grabbedById) {
      const origin = fighterPosition(local);
      const target = nearestCarryTarget(origin, local.direction, props.map((prop) => {
        const p = propPosition(prop);
        return { id: prop.id, x: p.x, z: p.z, carryable: !prop.broken && !prop.holderId };
      }), 2.45);
      focusedId = target?.id || null;
    }
    for (const prop of props) {
      const glow = prop.id === focusedId ? new B.Color3(0.18, 0.12, 0.025) : B.Color3.Black();
      for (const material of prop.visual?.metadata?.materials || []) material.emissiveColor = glow;
    }
  }

  function syncPropVisuals() {
    for (const prop of props) {
      if (prop.broken) continue;
      const p = prop.body.translation();
      const r = prop.body.rotation?.();
      prop.visual.position.set(p.x, p.y, p.z);
      if (r) prop.visual.rotationQuaternion = new B.Quaternion(r.x, r.y, r.z, r.w);
    }
  }

  function updatePropImpacts(now) {
    for (const prop of props) {
      if (prop.broken || prop.holderId || !prop.lastThrownBy || now > prop.throwArmedUntil) continue;
      const velocity = prop.body.linvel();
      const speed = Math.hypot(velocity.x, velocity.y, velocity.z);
      if (speed < 4) continue;
      const pp = prop.body.translation();
      for (const fighter of fighters) {
        if (!fighter.active || fighter.id === prop.lastThrownBy || now < fighter.invulnerableUntil) continue;
        const fp = fighter.body.translation();
        if (Math.hypot(fp.x - pp.x, fp.y - pp.y, fp.z - pp.z) > 1.12) continue;
        const last = prop.lastImpactAt.get(fighter.id) || 0;
        if (now - last < 450) continue;
        prop.lastImpactAt.set(fighter.id, now);
        const profile = throwProfile(prop.definition.id, speed);
        const dx = fp.x - pp.x;
        const dz = fp.z - pp.z;
        const len = Math.hypot(dx, dz) || 1;
        applyFighterHit(fighter, profile, { x: dx / len, z: dz / len }, prop.lastThrownBy, now, true);
        prop.throwArmedUntil = 0;
        if (prop.definition.breakable) damageProp(prop, impactDamage(speed, prop.definition.mass) * 0.65, now);
        break;
      }
      if (prop.throwArmedUntil <= now) continue;
      for (const target of props) {
        if (target === prop || target.broken || !target.definition.breakable) continue;
        const tp = target.body.translation();
        if (Math.hypot(tp.x - pp.x, tp.y - pp.y, tp.z - pp.z) > 1.18) continue;
        damageProp(target, impactDamage(speed, prop.definition.mass), now);
        prop.throwArmedUntil = 0;
        break;
      }
    }
  }

  function syncVisuals(now) {
    for (const fighter of fighters) {
      const p = fighter.body.translation();
      const v = fighter.body.linvel();
      const pose = fighterPose({
        now,
        speed: Math.hypot(v.x, v.z),
        attackKind: fighter.attackKind,
        attackUntil: fighter.attackUntil,
        dodgeUntil: fighter.dodgePoseUntil,
        hitStunUntil: fighter.hitStunUntil,
        knockedDownUntil: fighter.knockedDownUntil,
      });
      fighter.visual.position.set(p.x, p.y + (fighter.active ? pose.bob : 0), p.z);
      const floppy = !fighter.active || fighter.grabbedById || fighter.knockedDownUntil > now;
      if (floppy) {
        const r = fighter.body.rotation?.();
        fighter.visual.rotationQuaternion = r ? new B.Quaternion(r.x, r.y, r.z, r.w) : null;
        if (!r) {
          fighter.visual.rotation.x = 1.05;
          fighter.visual.rotation.z = 0.4;
        }
      } else {
        fighter.visual.rotationQuaternion = null;
        fighter.visual.rotation.y = Math.atan2(fighter.direction.x, fighter.direction.z);
        fighter.visual.rotation.x = -pose.lean;
        fighter.visual.rotation.z = pose.hitTilt * (fighter.slot % 2 === 0 ? -1 : 1);
      }
      const pulse = now < fighter.attackPulseUntil ? 1.11 : 1;
      const base = 1.08 * pulse;
      fighter.visual.scaling.set(base * pose.stretch, base * pose.squash, base * pose.stretch);

      const parts = fighter.visual.metadata || {};
      const stride = floppy ? 0 : Math.sin(now / 105) * Math.min(0.7, Math.hypot(v.x, v.z) * 0.11);
      if (parts.legs?.length === 2) {
        if (floppy) {
          parts.legs[0].rotation.x = 0.58;
          parts.legs[1].rotation.x = -0.42;
          parts.legs[0].rotation.z = 0.36;
          parts.legs[1].rotation.z = -0.31;
          parts.feet[0].rotation.x = -0.28;
          parts.feet[1].rotation.x = 0.34;
        } else {
          parts.legs[0].rotation.x = stride;
          parts.legs[1].rotation.x = -stride;
          parts.legs[0].rotation.z = 0;
          parts.legs[1].rotation.z = 0;
          parts.feet[0].rotation.x = stride * 0.45;
          parts.feet[1].rotation.x = -stride * 0.45;
        }
      }
      if (parts.head) {
        parts.head.rotation.x = floppy ? 0.12 : -pose.punchLift * 0.16;
        parts.head.rotation.z = floppy ? 0.18 : pose.hitTilt * (fighter.slot % 2 === 0 ? 1 : -1);
      }
      if (parts.shoulders?.length === 2 && !floppy) {
        parts.shoulders[0].rotation.z = -pose.punchLift * 0.32;
        parts.shoulders[1].rotation.z = pose.punchLift * 0.32;
      }
      if (parts.arms?.length === 2) {
        if (floppy) {
          parts.arms[0].rotation.x = 0.72;
          parts.arms[1].rotation.x = -0.55;
          parts.arms[0].rotation.z = -0.8;
          parts.arms[1].rotation.z = 0.85;
          parts.fists[0].position.z = 0.18;
          parts.fists[1].position.z = -0.06;
        } else {
          parts.arms[0].rotation.z = 0.18;
          parts.arms[1].rotation.z = -0.18;
          parts.arms[0].rotation.x = -stride * 0.65 - pose.punch * (fighter.attackKind === 'heavy' ? 0.85 : 0.28);
          parts.arms[1].rotation.x = stride * 0.65 - pose.punch * 1.25;
          parts.fists[0].position.z = 0.08 + pose.punch * 0.26;
          parts.fists[1].position.z = 0.08 + pose.punch * 0.56;
        }
      }
      if (parts.primary) {
        parts.primary.emissiveColor = pose.flash > 0
          ? new B.Color3(pose.flash * 0.52, pose.flash * 0.12, pose.flash * 0.08)
          : B.Color3.Black();
      }

      const groundY = surfaceYAt(p.x, p.z);
      fighter.shadow.position.set(p.x, groundY + 0.02, p.z);
      const height = Math.max(0, p.y - 1.1 - groundY);
      const shadowScale = Math.max(0.55, 1 - height * 0.08);
      fighter.shadow.scaling.set(shadowScale, 1, shadowScale);
      fighter.shadow.setEnabled(p.y > GAME_CONFIG.ringOutY - 2);
    }
    syncPropVisuals();
    updatePropHighlights();
  }

  function updateCamera() {
    const active = fighters.filter((fighter) => fighter.active).map((fighter) => {
      const p = fighter.body.translation();
      return { x: p.x, z: p.z };
    });
    const frame = cameraFrameForPoints(active);
    const placement = partyCameraPlacement(frame);
    const shakeAmount = settings.cameraShake ? shake : 0;
    const jitterX = (Math.random() - 0.5) * shakeAmount;
    const jitterY = (Math.random() - 0.5) * shakeAmount * 0.6;
    const targetPos = new B.Vector3(placement.x + jitterX, placement.y + jitterY, placement.z);
    camera.position = B.Vector3.Lerp(camera.position, targetPos, 0.085);
    camera.setTarget(new B.Vector3(placement.targetX, placement.targetY, placement.targetZ));
    shake *= 0.86;
    if (shake < 0.01) shake = 0;
  }

  function currentInput(fighter) {
    if (fighter.control.type === 'hybrid') return mergeInput(readKeyboard(keys), readGamepad(0));
    if (fighter.control.type === 'gamepad') return readGamepad(fighter.control.index) || neutralInput();
    if (fighter.control.type === 'bot') {
      const selfPos = fighterPosition(fighter);
      const target = nearestOpponent({ id: fighter.id, x: selfPos.x, z: selfPos.z, active: fighter.active }, fighters.map((other) => {
        const p = fighterPosition(other);
        return { id: other.id, x: p.x, z: p.z, active: other.active };
      }));
      if (!target) return neutralInput();
      return botIntent(selfPos, target, Math.random);
    }
    return neutralInput();
  }

  function grounded(fighter) {
    const p = fighter.body.translation();
    const v = fighter.body.linvel();
    const floor = surfaceYAt(p.x, p.z);
    return p.y <= floor + 1.18 && Math.abs(v.y) < 1.35;
  }

  function applyMovement(fighter, raw, edges, now) {
    const body = fighter.body;
    const velocity = body.linvel();
    const held = getHeldProp(fighter);
    const carrySpeedScale = held ? Math.max(0.58, 1 - held.definition.mass * 0.035) : 1;
    const move = movementVector(raw.moveX, raw.moveZ, GAME_CONFIG.moveSpeed * carrySpeedScale);
    const magnitude = Math.hypot(raw.moveX, raw.moveZ);
    if (magnitude > 0.08) {
      fighter.direction.x = move.x / Math.max(0.001, Math.hypot(move.x, move.z));
      fighter.direction.z = move.z / Math.max(0.001, Math.hypot(move.x, move.z));
    }

    if (now >= fighter.hitStunUntil) {
      body.setLinvel({ x: move.x, y: velocity.y, z: move.z }, true);
    }

    if (edges.jumpPressed && grounded(fighter) && now >= fighter.hitStunUntil) {
      body.setLinvel({ x: move.x, y: GAME_CONFIG.jumpImpulse, z: move.z }, true);
      audio.jump();
    }

    if (edges.dodgePressed && now >= fighter.dodgeReadyAt && now >= fighter.hitStunUntil) {
      fighter.dodgeReadyAt = now + 760;
      fighter.dodgePoseUntil = now + 230;
      fighter.invulnerableUntil = now + 220;
      fighter.hitStunUntil = now + 175;
      const dx = magnitude > 0.08 ? fighter.direction.x : fighter.direction.x;
      const dz = magnitude > 0.08 ? fighter.direction.z : fighter.direction.z;
      body.setLinvel({ x: dx * GAME_CONFIG.dodgeSpeed, y: Math.max(0.8, velocity.y), z: dz * GAME_CONFIG.dodgeSpeed }, true);
      audio.dodge();
    }
  }

  function applyFighterHit(target, profile, direction, attackerId, now, forceKnockdown = false) {
    if (!target?.active || now < target.invulnerableUntil) return false;
    const result = applyHit({ health: target.health }, profile);
    target.health = result.health;
    target.lastAttackerId = attackerId || null;
    target.lastAttackedAt = now;
    const damageScale = 1 + (GAME_CONFIG.maxHealth - target.health) / 150;
    const knockback = Math.min(18, Math.max(0, profile.knockback * damageScale));
    const hard = forceKnockdown || knockback >= 8.5 || profile.damage >= 14;
    target.hitStunUntil = now + (hard ? 390 : 220);
    if (hard) {
      target.knockedDownUntil = Math.max(target.knockedDownUntil, now + knockdownDuration(knockback, target.health));
      target.body.lockRotations?.(false, true);
      target.body.setAngvel?.({ x: direction.z * 3.2, y: 0.8, z: -direction.x * 3.2 }, true);
      releaseEverything(target, now);
    }
    target.body.setLinvel({ x: direction.x * knockback, y: 2.2 + knockback * 0.3, z: direction.z * knockback }, true);
    hitStopUntil = Math.max(hitStopUntil, now + hitStopDuration(profile.damage, hard));
    audio.hit(hard);
    const tp = target.body.translation();
    spawnImpact(B, scene, new B.Vector3(tp.x, tp.y + 0.25, tp.z), hard ? '#f6c83f' : '#fff0cf', hard, (value) => { shake = Math.max(shake, value); });
    if (target.health <= 0) knockOut(target, attackerId, 'KNOCKED OUT');
    return true;
  }

  function performAttack(attacker, kind, now) {
    const held = getHeldProp(attacker);
    const profile = held ? heldAttackProfile(held.definition.id) : (kind === 'heavy' ? GAME_CONFIG.heavyAttack : GAME_CONFIG.lightAttack);
    if (now < attacker.attackReadyAt || now < attacker.hitStunUntil || now < attacker.knockedDownUntil || !attacker.active || attacker.grabbedById) return;
    attacker.attackReadyAt = now + profile.cooldownMs;
    const heavyVisual = Boolean(held) || kind === 'heavy';
    attacker.attackPulseUntil = now + (heavyVisual ? 210 : 135);
    attacker.attackKind = heavyVisual ? 'heavy' : 'light';
    attacker.attackUntil = now + (heavyVisual ? 250 : 155);
    const origin = attacker.body.translation();
    let connected = false;

    for (const target of fighters) {
      if (target.id === attacker.id || !target.active || now < target.invulnerableUntil) continue;
      const tp = target.body.translation();
      const dx = tp.x - origin.x;
      const dz = tp.z - origin.z;
      const distance = Math.hypot(dx, dz);
      if (distance > profile.range || distance < 0.001) continue;
      const nx = dx / distance;
      const nz = dz / distance;
      const facingDot = nx * attacker.direction.x + nz * attacker.direction.z;
      if (facingDot < -0.02) continue;
      connected = applyFighterHit(target, profile, { x: nx, z: nz }, attacker.id, now, heavyVisual);
      if (connected) break;
    }

    if (!connected) {
      const propTarget = nearestCarryTarget(origin, attacker.direction, props.map((prop) => {
        const p = propPosition(prop);
        return { id: prop.id, x: p.x, z: p.z, carryable: !prop.broken && !prop.holderId && Number.isFinite(prop.hp), ref: prop };
      }), profile.range);
      if (propTarget?.ref) {
        damageProp(propTarget.ref, profile.damage, now);
        const pp = propTarget.ref.body.translation();
        spawnImpact(B, scene, new B.Vector3(pp.x, pp.y, pp.z), '#f2c94c', heavyVisual, (value) => { shake = Math.max(shake, value); });
      }
    }
  }

  function updateFighter(fighter, now) {
    if (!fighter.active || matchOver || fighter.grabbedById) return;
    if (fighter.knockedDownUntil > now) {
      fighter.previousInput = neutralInput();
      return;
    }
    if (fighter.knockedDownUntil) {
      fighter.knockedDownUntil = 0;
      fighter.body.lockRotations?.(true, true);
      fighter.body.setRotation?.({ x: 0, y: 0, z: 0, w: 1 }, true);
      fighter.body.setAngvel?.({ x: 0, y: 0, z: 0 }, true);
    }
    const raw = currentInput(fighter);
    const edges = createInputEdges(fighter.previousInput, raw);
    fighter.previousInput = raw;
    applyMovement(fighter, raw, edges, now);
    if (edges.lightPressed) performAttack(fighter, 'light', now);
    if (edges.heavyPressed) performAttack(fighter, 'heavy', now);
    if (edges.grabPressed) performGrab(fighter, now);
    if (fighter.control.type === 'bot' && !fighter.heldPropId && !fighter.grabbedFighterId && Math.random() < 0.012) performGrab(fighter, now);
  }

  function knockOut(victim, scorerId, reason = 'KNOCKED OUT') {
    if (!victim.active || matchOver) return;
    const now = performance.now();
    releaseEverything(victim, now);
    victim.active = false;
    victim.ko = true;
    victim.health = 0;
    victim.grabbedById = null;
    victim.knockedDownUntil = Number.POSITIVE_INFINITY;
    victim.hitStunUntil = Number.POSITIVE_INFINITY;
    victim.body.lockRotations?.(false, true);
    const v = victim.body.linvel();
    if (Math.hypot(v.x, v.z) < 2) victim.body.setLinvel({ x: 1.5, y: 4.2, z: -1.2 }, true);
    victim.body.setAngvel?.({ x: 4.5, y: 1.3, z: -3.6 }, true);

    const scorer = fighters.find((fighter) => fighter.id === scorerId && fighter.id !== victim.id) || null;
    if (scorer) scorer.score += 1;
    audio.ringOut();
    onBanner(`${victim.style.name} — ${reason}!`);
    schedule(onBannerClear, 900);
    pushHud();

    const winnerId = roundWinner({ active: Object.fromEntries(fighters.map((fighter) => [fighter.id, fighter.active])) });
    if (winnerId) {
      const winner = fighters.find((fighter) => fighter.id === winnerId);
      matchOver = true;
      audio.stopMusic();
      audio.win();
      schedule(() => onResult({
        winner: winner?.style.name || 'Winner',
        scores: fighters.map((fighter) => ({ id: fighter.id, name: fighter.style.name, score: fighter.score, health: fighter.health })),
      }), 1050);
    }
  }

  function recoverFromFall(fighter, now) {
    releaseEverything(fighter, now);
    fighter.lastAttackerId = null;
    fighter.hitStunUntil = now + 420;
    fighter.knockedDownUntil = 0;
    fighter.invulnerableUntil = now + 850;
    fighter.body.lockRotations?.(true, true);
    fighter.body.setRotation?.({ x: 0, y: 0, z: 0, w: 1 }, true);
    fighter.body.setAngvel?.({ x: 0, y: 0, z: 0 }, true);
    fighter.body.setTranslation({ x: fighter.spawn.x, y: fighter.spawn.y + 0.25, z: fighter.spawn.z }, true);
    fighter.body.setLinvel({ x: 0, y: 0, z: 0 }, true);
  }

  function checkRingOuts(now) {
    const halfX = currentArena.size.x / 2;
    const halfZ = currentArena.size.z / 2;
    for (const fighter of fighters) {
      if (!fighter.active) continue;
      const p = fighter.body.translation();
      if (p.y < GAME_CONFIG.ringOutY || Math.abs(p.x) > halfX + 3 || Math.abs(p.z) > halfZ + 3) {
        const recentAttacker = now - fighter.lastAttackedAt < 5000 ? fighter.lastAttackerId : null;
        fighter.health = Math.max(0, fighter.health - 18);
        if (fighter.health <= 0) {
          knockOut(fighter, recentAttacker, 'FELL OUT COLD');
        } else {
          recoverFromFall(fighter, now);
          audio.ringOut();
          onBanner(`${fighter.style.name} FELL OUT — 18 HP LOST`);
          schedule(onBannerClear, 820);
          pushHud();
        }
      }
    }
  }

  function updateHazards(now) {
    for (const hazard of hazards) {
      hazard.angle += hazard.speed * FIXED_STEP;
      hazard.root.rotation.y = hazard.angle;
      const cos = Math.cos(-hazard.angle);
      const sin = Math.sin(-hazard.angle);
      for (const fighter of fighters) {
        if (!fighter.active || now < fighter.invulnerableUntil) continue;
        const p = fighter.body.translation();
        const dx = p.x - hazard.x;
        const dz = p.z - hazard.z;
        const localX = dx * cos - dz * sin;
        const localZ = dx * sin + dz * cos;
        if (Math.abs(localX) > hazard.radius + 0.4 || Math.abs(localZ) > 0.62 || Math.abs(p.y - hazard.y) > 1.7) continue;
        const previousHit = hazard.hitAt.get(fighter.id) || 0;
        if (now - previousHit < 700) continue;
        hazard.hitAt.set(fighter.id, now);
        const side = localZ >= 0 ? 1 : -1;
        const worldX = -Math.sin(hazard.angle) * side;
        const worldZ = Math.cos(hazard.angle) * side;
        fighter.hitStunUntil = now + 360;
        fighter.lastAttackerId = null;
        fighter.body.setLinvel({ x: worldX * 9, y: 4.8, z: worldZ * 9 }, true);
        audio.hit(true);
        spawnImpact(B, scene, new B.Vector3(p.x, p.y, p.z), '#f5c842', true, (value) => { shake = Math.max(shake, value); });
      }
    }
  }

  function pushHud() {
    onHud(fighters.map((fighter) => {
      const held = getHeldProp(fighter);
      return {
        id: fighter.id,
        name: fighter.style.name,
        score: fighter.score,
        health: fighter.health,
        active: fighter.active,
        ko: fighter.ko,
        heldItem: held?.definition.name || (fighter.grabbedFighterId ? 'Opponent' : ''),
        danger: 0,
      };
    }));
  }

  function fixedUpdate(now, inputLocked = false) {
    if (!inputLocked) {
      for (const fighter of fighters) updateFighter(fighter, now);
      updateHazards(now);
    }
    syncHeldTargets(now);
    world.step();
    updatePropImpacts(now);
    checkRingOuts(now);
  }

  function frame() {
    if (!running || !scene) return;
    const now = performance.now();
    if (!lastFrame) lastFrame = now;
    const delta = Math.min(0.05, (now - lastFrame) / 1000);
    lastFrame = now;

    const countdown = countdownState(now - matchStartedAt);
    if (countdown.label !== lastCountdownLabel) {
      lastCountdownLabel = countdown.label;
      if (countdown.label) onBanner(countdown.label);
      else onBannerClear();
    }

    if (!paused) {
      const impactFrozen = now < hitStopUntil;
      if (!impactFrozen) {
        accumulator += delta;
        while (accumulator >= FIXED_STEP) {
          fixedUpdate(now, countdown.locked || matchOver);
          accumulator -= FIXED_STEP;
          if (now < hitStopUntil) {
            accumulator = 0;
            break;
          }
        }
      } else {
        accumulator = 0;
      }
      syncVisuals(now);
      updateCamera();
    } else {
      accumulator = 0;
    }

    if (now - lastHud > 140) {
      pushHud();
      lastHud = now;
    }
    scene.render();
  }

  async function startMatch(options = {}) {
    await ensureRuntime();
    stopMatch(false);
    settings = { ...settings, ...(options.settings || {}) };
    audio.updateSettings(settings);
    audio.unlock();
    audio.startMusic('fight');
    currentArena = getArena(options.arenaId);
    onStatus(`Building ${currentArena.name}…`);
    buildScene(currentArena);

    const styles = styleOrder(options.fighterId);
    const total = Math.max(2, Math.min(4, 1 + (Number(options.botCount) || 3)));
    const pads = globalThis.navigator?.getGamepads?.() || [];
    fighters = [];
    for (let i = 0; i < total; i++) {
      let control;
      if (i === 0) control = { type: 'hybrid', index: 0 };
      else if (pads[i]) control = { type: 'gamepad', index: i };
      else control = { type: 'bot' };
      fighters.push(createFighter(i, currentArena.spawns[i], styles[i], control));
    }

    running = true;
    paused = false;
    matchOver = false;
    matchStartedAt = performance.now();
    pausedAt = 0;
    lastCountdownLabel = null;
    accumulator = 0;
    lastFrame = 0;
    lastHud = 0;
    hitStopUntil = 0;
    pushHud();
    onBanner('3');
    lastCountdownLabel = '3';
    onStatus('Ready');
    engine.stopRenderLoop();
    engine.runRenderLoop(frame);
    return true;
  }

  function stopMatch(clearScene = true) {
    running = false;
    paused = false;
    pausedAt = 0;
    matchOver = false;
    hitStopUntil = 0;
    clearTimers();
    keys.clear();
    audio.stopMusic();
    if (engine) engine.stopRenderLoop();
    if (clearScene) {
      fighters = [];
      hazards = [];
      props = [];
      scene?.dispose();
      scene = null;
      world?.free?.();
      world = null;
    }
  }

  function startMenuAudio() {
    audio.unlock();
    audio.startMusic('menu');
  }

  function setPaused(nextPaused) {
    const now = performance.now();
    const requested = Boolean(nextPaused) && running && !matchOver;
    if (requested === paused) return paused;
    if (requested) {
      paused = true;
      pausedAt = now;
      audio.stopMusic();
    } else {
      if (pausedAt && matchStartedAt) matchStartedAt += now - pausedAt;
      paused = false;
      pausedAt = 0;
      if (running) audio.startMusic('fight');
    }
    accumulator = 0;
    lastFrame = now;
    return paused;
  }

  function setSettings(next) {
    settings = { ...settings, ...next };
    audio.updateSettings(settings);
  }

  function dispose() {
    stopMatch(true);
    audio.dispose();
    engine?.dispose();
    engine = null;
  }

  function onKeyDown(event) {
    if (['Space', 'KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyH', 'KeyJ', 'KeyK', 'KeyL'].includes(event.code)) event.preventDefault();
    keys.add(event.code);
  }
  function onKeyUp(event) { keys.delete(event.code); }
  globalThis.addEventListener?.('keydown', onKeyDown, { passive: false });
  globalThis.addEventListener?.('keyup', onKeyUp);

  return { startMenuAudio, startMatch, stopMatch, setPaused, setSettings, dispose };
}
